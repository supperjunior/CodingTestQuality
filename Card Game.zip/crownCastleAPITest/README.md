# Project Title

CrownCastle Code Screen Task (The Card Game)

## Getting Started

### Prerequisites

- Runnable on: Windows 10
- Browser: Chrome
- Tools: Java, Selenium Webdriver, TestNG, Allure Report, Maven


### Testcase steps:

1.	Navigate to https://deckofcardsapi.com/
2.	Confirm the site is up
3.	Get a new deck
4.	Shuffle it
5.	Deal three cards to each of two players
6.	Check whether either has blackjack
7.	If either has, write out which one does



