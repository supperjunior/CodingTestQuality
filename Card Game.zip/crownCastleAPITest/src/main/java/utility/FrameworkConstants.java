package utility;

public interface FrameworkConstants {
	
	public static final String CONFIG_FILE_PATH = "./Test_Configuration/Config.properties";	
}
