
import org.testng.Assert;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given; //import this
import io.restassured.RestAssured;
import io.restassured.response.Response;
import utility.AllureLogger;
import utility.BaseTest;

public class CardGameTest extends BaseTest {
	
    
	@Test(description="The Card Game") 
	public void getBookingIDs(){
		
		AllureLogger.logToAllure("Starting the test");
		/*******************************************************
		 * Send a GET request to /booking/{id}
		 * and check that the response has HTTP status code 200
		 ******************************************************/
	     // 1. & 2. Confirm the site is up
		AllureLogger.logToAllure("Confirm the site is up");
        RestAssured.baseURI = readConfigurationFile("Base_URI");
        given().get("/").then().statusCode(200);
        
		// Get a new deck
		AllureLogger.logToAllure("Get a new deck");
		Response response = given().spec(requestSpec).when().get("/api/deck/new");
		response.then().spec(responseSpec);		
		logResponseAsString(response);
		String deckId = response.jsonPath().getString("deck_id");
		Assert.assertTrue(response.jsonPath().getString("shuffled").toString().equals("false"));
		Assert.assertTrue(response.jsonPath().getString("remaining").toString().equals("52"));

		// Shuffle it
		AllureLogger.logToAllure("Shuffle it");
		Response responseShuffle = given().get("/api/deck/" + deckId + "/shuffle/");
		responseShuffle.then().spec(responseSpec);
		Assert.assertTrue(responseShuffle.jsonPath().getString("shuffled").toString().equals("true"));
		Assert.assertTrue(responseShuffle.jsonPath().getString("remaining").toString().equals("52"));
		
		// Deal three cards to each of two players
		AllureLogger.logToAllure("Deal three cards to each of two players");
	    Response playerOneResponse = given().queryParam("count", 3).get("/api/deck/" + deckId + "/draw/");
	    logResponseAsString(playerOneResponse);
	    Assert.assertTrue(playerOneResponse.jsonPath().getString("deck_id").toString().equals(deckId));
		Assert.assertTrue(playerOneResponse.jsonPath().getString("remaining").toString().equals("49"));
		
	    Response playerTwoResponse = given().queryParam("count", 3).get("/api/deck/" + deckId + "/draw/");
	    logResponseAsString(playerTwoResponse);
	    Assert.assertTrue(playerTwoResponse.jsonPath().getString("deck_id").toString().equals(deckId));
		Assert.assertTrue(playerTwoResponse.jsonPath().getString("remaining").toString().equals("46"));
		
        // Process cards for both players to check for blackjack
		AllureLogger.logToAllure("Process cards for both players to check for blackjack");
        boolean playerOneBlackjack = hasBlackjack(playerOneResponse);
        boolean playerTwoBlackjack = hasBlackjack(playerTwoResponse);

        // Check whether either has blackjack and write out which one does
        AllureLogger.logToAllure("Check whether either has blackjack and write out which one does");
        System.out.println("*******************************");
        if (playerOneBlackjack) {
            System.out.println("Player One has Blackjack!");
        }
        if (playerTwoBlackjack) {
            System.out.println("Player Two has Blackjack!");
        }
        if (!playerOneBlackjack && !playerTwoBlackjack) {
            System.out.println("Neither player has Blackjack.");
        }
        System.out.println("*******************************");
	}
}
