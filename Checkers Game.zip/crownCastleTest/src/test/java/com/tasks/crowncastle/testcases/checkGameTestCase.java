package com.tasks.crowncastle.testcases;

import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;

import java.util.Random;

import org.testng.annotations.*;

import com.tasks.crowncastle.ScriptBase;
import com.tasks.crowncastle.pages.HomePage.EnvironmentType;

@Epic("Tests")
@Feature("Order Page")
public class checkGameTestCase extends ScriptBase {

	/**************************** Test Data ****************************/
	Random rn = new Random();
	protected int number = rn.nextInt(10) + 1;

	/**************************** END ****************************/
	
	@BeforeClass
	public void setUp() throws InterruptedException{
		homepage.setUpEnv();
		// Step 1: Go to the url
		homepage.loadURL(EnvironmentType.test_env);
	}

    @Test (priority = 0, description="Verify add to the cart")
    @Severity(SeverityLevel.NORMAL)
    @Description("")
    @Story("")
	public void testAddToCart() {
    	
    	
    	// Step 2: play games for 5 time.
    	homepage.firstMove();
    	homepage.gameMoves(2, 40, 51);
    	homepage.gameMoves(3, 29, 40);
    	homepage.gameMoves(4, -11, 11);
    	homepage.gameMoves(5, -11, 2); // will taking a blue piece
    	
    	// Step 3: restart games
    	homepage.resetGame();
	}

	@AfterClass
	public void cleanUp() {
		// Clean up env
		homepage.cleanUpEnv();
	}

}