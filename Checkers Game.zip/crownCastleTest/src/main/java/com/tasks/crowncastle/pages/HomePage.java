package com.tasks.crowncastle.pages;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.tasks.crowncastle.utils.BasePage;
import com.tasks.crowncastle.utils.EnvironmentCleanUp;

import junit.framework.Assert;

public class HomePage extends BasePage {

	private static Logger log = Logger.getLogger(HomePage.class.getName());

	private final String url = "https://www.gamesforthebrain.com/game/checkers";

	/***************** Web Object Element ********************/
	private String yellowPieceEle = "space";
	private String messageEle = "message";
	private String restartBtn = "//a[contains(text(),'Restart')]";
	
	/**************************** END **********************************/

	/***************** Expected String Text ********************/
	private String expectedTitleText = "Checkers - Games for the Brain";
	private String restartMessage = "Select an orange piece to move.";
	private String moveMessage = "Make a move.";
	private int defaultSaceNumber = 22;

	/**************************** END **********************************/

	/**
	 * Method Name : <b>setUpEnv</b> <br>
	 * Description : This method will set up Env.</br>
	 * 
	 */
	public void setUpEnv() {
		log.info(String.format("setupEnv()"));

		// EnvironmentCleanUp.envCleanup();
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		options.addArguments("--allow-insecure-localhost");
		driver = new ChromeDriver(options);
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		delayFor(2);
	}

	/**
	 * Method Name : <b>cleanUpEnv</b> <br>
	 * Description : This method will clean up Env.</br>
	 * 
	 */
	public void cleanUpEnv() {
		log.info(String.format("cleanUpEnv()"));

		driver.close();
		driver.quit();
		delayFor(2);
	}

	public enum EnvironmentType {
		test_env
	}

	private String getEnvironmentTypeURL(EnvironmentType environmentType) {

		String tempURL = "";
		if (environmentType == EnvironmentType.test_env) {
			tempURL = url;
		}
		return tempURL;
	}

	/**
	 * Method Name : <b>loadURL</b> <br>
	 * Description : This method will load the url.</br>
	 * Author: Zhen Kuang Date:
	 * 
	 */
	public void loadURL(EnvironmentType environmentType) throws InterruptedException {
		log.info(String.format("Browse URL : " + getEnvironmentTypeURL(environmentType) + " login to the application"));

		try {
			driver.get(getEnvironmentTypeURL(environmentType));
			String title = driver.getTitle();
			// Confirm that the site is up
			Assert.assertTrue(title.trim().equalsIgnoreCase(expectedTitleText));

		} catch (Exception e) {
			String getTitle = driver.getTitle();
			log.info(String.format("Unable to open the website : " + getTitle));
			e.printStackTrace();
			throw new Error("Unable to open the website");
		}

	}

	/**
	 * Method Name : <b>moveFirstYelloPiece</b> <br>
	 * Description : This method will click and move the first yellow piece.</br>
	 * Author: Zhen Kuang
	 *
	 * 
	 */
	public void firstMove() {
		log.info(String.format("Move Step: (%d)", 1));

		click(By.name(yellowPieceEle + String.valueOf(defaultSaceNumber)));
		click(By.name(yellowPieceEle + String.valueOf(defaultSaceNumber + 11)));
	}

	/**
	 * Method Name : <b>moveFirstYelloPiece</b> <br>
	 * Description : This method will click and move the first yellow piece.</br>
	 * Author: Zhen Kuang
	 *
	 * 
	 */
	public boolean comfirmPlayMessage() {
		log.info(String.format("Confirm Continuoue Message"));

		return readText(By.id(messageEle)).trim().equalsIgnoreCase(moveMessage);
	}

	/**
	 * Method Name : <b>moveFirstYelloPiece</b> <br>
	 * Description : This method will click and move the first yellow piece.</br>
	 * Author: Zhen Kuang
	 *
	 * 
	 */
	public void gameMoves(int count, int location1, int location2) {
		log.info(String.format("Move Step: (%d)", count));

		if (comfirmPlayMessage() == true) {
			click(By.name(yellowPieceEle + String.valueOf(defaultSaceNumber + location1)));
			click(By.name(yellowPieceEle + String.valueOf(defaultSaceNumber + location2)));
		} else {
			Assert.assertTrue(false);
		}
	}
	
	/**
	 * Method Name : <b>moveFirstYelloPiece</b> <br>
	 * Description : This method will click and move the first yellow piece.</br>
	 * Author: Zhen Kuang
	 *
	 * 
	 */
	public void resetGame() {
		log.info(String.format("Restart Game"));

		click(By.xpath(restartBtn));
		Assert.assertTrue(readText(By.id(messageEle)).trim().equalsIgnoreCase(restartMessage));	
	}

}
