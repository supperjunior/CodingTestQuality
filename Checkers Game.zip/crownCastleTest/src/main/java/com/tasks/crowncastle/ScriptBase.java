package com.tasks.crowncastle;

import com.tasks.crowncastle.pages.HomePage;


public class ScriptBase {
	
	public HomePage homepage = new HomePage();
	
}
