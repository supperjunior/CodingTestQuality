# Project Title

CrownCastle Code Screen Task (The Checkers Game)

## Getting Started

### Prerequisites

- Runnable on: Windows 10
- Browser: Chrome
- Tools: Java, Selenium Webdriver, TestNG, Allure Report, Maven


### Testcase steps:

1.	Navigate to https://www.gamesforthebrain.com/game/checkers/
2.	Confirm that the site is up
3.	Make five legal moves as orange:
a)	Include taking a blue piece
b)	Use “Make a move” as confirmation that you can take the next step
c)	Restart the game after five moves
d)	Confirm that the restarting had been successful


